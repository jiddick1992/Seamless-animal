const q=document.getElementById('q'), animal=document.getElementById('animal'), style=document.getElementById('style'), use=document.getElementById('use');
const count=document.getElementById('count'), results=document.getElementById('results');
function fill(sel,key){[...new Set(DATA.map(x=>x[key]))].sort().forEach(v=>sel.add(new Option(v,v)))}
fill(animal,'Animal');fill(style,'Style');fill(use,'Use Case');
function esc(s){return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function copyText(t){if(navigator.clipboard)navigator.clipboard.writeText(t).then(()=>alert('Copied'));else alert('Clipboard unavailable')}
function filtered(){
let term=q.value.toLowerCase(),a=animal.value,s=style.value,u=use.value;
return DATA.filter(x=>(!term||Object.values(x).join(' ').toLowerCase().includes(term))&&(!a||x.Animal===a)&&(!s||x.Style===s)&&(!u||x['Use Case']===u));
}
function render(){
let arr=filtered(),shown=arr.slice(0,30);
count.innerHTML='<small>Showing '+shown.length+' of '+arr.length+' matches</small>';
results.innerHTML=shown.map(x=>'<section class="card"><div><b>'+esc(x.ID)+' — '+esc(x.Title)+'</b></div>'+
'<span class="badge">'+esc(x.Animal)+'</span><span class="badge">'+esc(x.Style)+'</span><span class="badge">'+esc(x['Use Case'])+'</span>'+
'<div class="grid"><div><label>AI Prompt</label><textarea readonly>'+esc(x['AI Prompt'])+'</textarea><button onclick="copyText('+JSON.stringify(x['AI Prompt'])+')">Copy prompt</button></div>'+
'<div><label>Negative Prompt</label><textarea readonly>'+esc(x['Negative Prompt'])+'</textarea><button onclick="copyText('+JSON.stringify(x['Negative Prompt'])+')">Copy negative</button></div>'+
'<div><label>Title</label><textarea readonly>'+esc(x.Title)+'</textarea></div>'+
'<div><label>Keywords</label><textarea readonly>'+esc(x['Keywords (25)'])+'</textarea><button onclick="copyText('+JSON.stringify(x['Keywords (25)'])+')">Copy keywords</button></div></div></section>').join('');
}
[q,animal,style,use].forEach(el=>el.addEventListener('input',render));
[q,animal,style,use].forEach(el=>el.addEventListener('change',render));
document.getElementById('export').onclick=()=>{
const arr=filtered(), head=Object.keys(DATA[0]), escCsv=v=>'"'+String(v??'').replace(/"/g,'""')+'"';
const csv=[head.map(escCsv).join(','),...arr.map(r=>head.map(k=>escCsv(r[k])).join(','))].join('\n');
const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));a.download='animal-pattern-filtered.csv';a.click();
};
let deferred;
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferred=e;document.getElementById('install').hidden=false});
document.getElementById('install').onclick=async()=>{if(!deferred)return;deferred.prompt();await deferred.userChoice;deferred=null};
if('serviceWorker' in navigator) window.addEventListener('load',()=>navigator.serviceWorker.register('sw.js'));
render();
